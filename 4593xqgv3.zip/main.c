#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char name[50];
    float price;
    int quantity;
} Item;

void read_line(char *buf, int size) {
    if (fgets(buf, size, stdin)) {
        buf[strcspn(buf, "\n")] = '\0';
    }
}

void add_item(Item **list, int *count, int *capacity) {
    if (*count == *capacity) {
        int new_cap = *capacity * 2;
        Item *tmp = realloc(*list, new_cap * sizeof(Item));
        if (!tmp) {
            printf("Memory allocation failed. Item not added.\n");
            return;
        }
        *list = tmp;
        *capacity = new_cap;
    }

    Item *it = &(*list)[*count];
    char buf[64];

    printf("Enter item name: ");
    read_line(it->name, sizeof(it->name));

    printf("Enter price: ");
    read_line(buf, sizeof(buf));
    it->price = (float)atof(buf);

    printf("Enter quantity: ");
    read_line(buf, sizeof(buf));
    it->quantity = atoi(buf);

    (*count)++;

    printf("Item added. Count: %d, Capacity: %d\n", *count, *capacity);
}

void display_list(Item *list, int count) {
    float grand = 0.0f;

    printf("\n===== Shopping List =====\n");
    printf("%-4s %-20s %-5s %-10s %-10s\n", "No", "Item", "Qty", "Price", "Total");

    for (int i = 0; i < count; i++) {
        float line = list[i].price * list[i].quantity;
        grand += line;
        printf("%-4d %-20s %-5d Rs %-7.2f Rs %-7.2f\n",
               i + 1, list[i].name, list[i].quantity, list[i].price, line);
    }

    printf("-------------------------------------------------------\n");
    printf("Grand Total: Rs %.2f\n", grand);
    printf("=======================\n");
}

void remove_item(Item *list, int *count, int index) {
    if (index < 0 || index >= *count) {
        printf("Invalid index.\n");
        return;
    }
    for (int i = index; i < *count - 1; i++) {
        list[i] = list[i + 1];
    }
    (*count)--;
    printf("Item removed.\n");
}

float compute_total(Item *list, int count) {
    float total = 0.0f;
    for (int i = 0; i < count; i++) {
        total += list[i].price * list[i].quantity;
    }
    return total;
}

void clear_list(Item **list, int *count, int *capacity) {
    free(*list);
    *list = malloc(2 * sizeof(Item));
    if (!*list) {
        printf("Memory allocation failed.\n");
        exit(1);
    }
    *count = 0;
    *capacity = 2;
    printf("List cleared.\n");
}

int main(void) {
    int capacity = 2;
    int count = 0;
    Item *list = malloc(capacity * sizeof(Item));
    if (!list) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    int choice;
    char buf[64];

    while (1) {
        printf("\n===== Shopping List =====\n");
        printf("1. Add Item\n");
        printf("2. View List\n");
        printf("3. Remove Item\n");
        printf("4. Clear List\n");
        printf("5. Exit\n");
        printf("=========================\n");
        printf("Choose: ");

        read_line(buf, sizeof(buf));
        choice = atoi(buf);

        if (choice == 1) {
            add_item(&list, &count, &capacity);
        } else if (choice == 2) {
            display_list(list, count);
        } else if (choice == 3) {
            printf("Enter item number to remove: ");
            read_line(buf, sizeof(buf));
            int num = atoi(buf);
            remove_item(list, &count, num - 1);
        } else if (choice == 4) {
            clear_list(&list, &count, &capacity);
        } else if (choice == 5) {
            break;
        } else {
            printf("Invalid choice.\n");
        }
    }

    printf("\nTotal amount spent in this session: Rs %.2f\n", compute_total(list, count));
    free(list);
    return 0;
}