
#include <stdio.h>

int main()
{
    int correctPIN = 4821;
    int enteredPIN;
    int attempts = 3;
    int login = 0;

    double balance = 12500.00;
    int choice, amount;
    int txnCount = 0;

    // TASK 1: PIN VERIFICATION

    while (attempts > 0)
    {
        printf("\nEnter PIN: ");
        scanf("%d", &enteredPIN);

        if (enteredPIN == correctPIN)
        {
            printf("\nLogin Successful! Welcome.\n");
            login = 1;
            break;
        }
        else
        {
            attempts--;

            if (attempts > 0)
            {
                printf("Incorrect PIN. %d attempts remaining.\n", attempts);
            }
            else
            {
                printf("Incorrect PIN. Your card has been blocked.\n");
                printf("Please visit your nearest branch.\n");
            }
        }
    }

    // TASK 2 AND 3: TRANSACTION MENU

    if (login == 1)
    {
        while (1)
        {
            printf("\n===== WELCOME =====\n");
            printf("Balance: Rs. %.2f\n", balance);
            printf("-------------------\n");
            printf("1. Check Balance\n");
            printf("2. Withdraw\n");
            printf("3. Deposit\n");
            printf("4. Exit\n");
            printf("===================\n");

            printf("Enter your choice: ");
            scanf("%d", &choice);

            switch (choice)
            {
                case 1:
                    printf("Current Balance: Rs. %.2f\n", balance);
                    break;

                case 2:
                    if (txnCount == 5)
                    {
                        printf("Transaction limit reached. Please re-login.\n");
                        return 0;
                    }

                    printf("Enter withdrawal amount: ");
                    scanf("%d", &amount);

                    if (amount <= 0)
                    {
                        printf("Invalid amount.\n");
                    }
                    else if (amount > balance)
                    {
                        printf("Insufficient balance.\n");
                    }
                    else if (amount % 100 != 0)
                    {
                        printf("Amount must be a multiple of 100.\n");
                    }
                    else
                    {
                        balance = balance - amount;
                        txnCount++;

                        printf("\nTransaction: Withdrawal\n");
                        printf("Amount: Rs. %.2f\n", (double)amount);
                        printf("Balance: Rs. %.2f\n", balance);
                        printf("Txn No.: %d\n", txnCount);
                    }
                    break;

                case 3:
                    if (txnCount == 5)
                    {
                        printf("Transaction limit reached. Please re-login.\n");
                        return 0;
                    }

                    printf("Enter deposit amount: ");
                    scanf("%d", &amount);

                    if (amount <= 0)
                    {
                        printf("Invalid deposit amount.\n");
                    }
                    else
                    {
                        balance = balance + amount;
                        txnCount++;

                        printf("\nTransaction: Deposit\n");
                        printf("Amount: Rs. %.2f\n", (double)amount);
                        printf("Balance: Rs. %.2f\n", balance);
                        printf("Txn No.: %d\n", txnCount);
                    }
                    break;

                case 4:
                    printf("Final Balance: Rs. %.2f\n", balance);
                    printf("Thank you for using our ATM!\n");
                    return 0;

                default:
                    printf("Invalid choice. Try again.\n");
            }

            if (txnCount == 5)
            {
                printf("\nTransaction limit reached. Please re-login.\n");
                break;
            }
        }
    }

    return 0;
}