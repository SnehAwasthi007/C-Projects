
#include <stdio.h>

// TASK 1: Conversion functions

void celsius_to_fahrenheit(float *temp)
{
    *temp = (*temp * 9.0 / 5.0) + 32;
}

void celsius_to_kelvin(float *temp)
{
    *temp = *temp + 273.15;
}

void fahrenheit_to_celsius(float *temp)
{
    *temp = (*temp - 32) * 5.0 / 9.0;
}

void kelvin_to_celsius(float *temp)
{
    *temp = *temp - 273.15;
}


// TASK 2: Array conversion using function pointer

void convert_array(float arr[], int n,
                   void (*convert_fn)(float *))
{
    int i;

    for (i = 0; i < n; i++)
    {
        convert_fn(&arr[i]);
    }
}


// TASK 3: Find hottest city

void find_hottest(float arr[], char cities[][30], int n,
                  float **max_temp, char **max_city)
{
    int i, max = 0;

    for (i = 1; i < n; i++)
    {
        if (arr[i] > arr[max])
        {
            max = i;
        }
    }

    *max_temp = &arr[max];
    *max_city = cities[max];
}


// Find coldest city

void find_coldest(float arr[], char cities[][30], int n,
                  float **min_temp, char **min_city)
{
    int i, min = 0;

    for (i = 1; i < n; i++)
    {
        if (arr[i] < arr[min])
        {
            min = i;
        }
    }

    *min_temp = &arr[min];
    *min_city = cities[min];
}


// Average using pointer traversal

float average_temp(float arr[], int n)
{
    int i;
    float sum = 0;

    for (i = 0; i < n; i++)
    {
        sum = sum + *(arr + i);
    }

    return sum / n;
}


// MAIN FUNCTION

int main()
{
    char cities[8][30] = {
        "Delhi", "Mumbai", "Chennai", "Kolkata",
        "Bengaluru", "Hyderabad", "Jaipur", "Pune"
    };

    float temps[8] = {
        42.1, 36.5, 38.8, 34.2,
        28.9, 40.3, 45.6, 33.1
    };

    float *max_temp, *min_temp;
    char *max_city, *min_city;

    int i;
    char choice;

    // Task 1: Test conversion functions

    float temp = 100.0;

    printf("Original Celsius: %.2f\n", temp);

    celsius_to_fahrenheit(&temp);

    printf("Fahrenheit: %.2f\n", temp);

    float test = 0;

    celsius_to_fahrenheit(&test);
    printf("0 Celsius = %.2f Fahrenheit\n", test);

    test = 0;
    celsius_to_kelvin(&test);
    printf("0 Celsius = %.2f Kelvin\n", test);

    test = 212;
    fahrenheit_to_celsius(&test);
    printf("212 Fahrenheit = %.2f Celsius\n", test);

    test = 373.15;
    kelvin_to_celsius(&test);
    printf("373.15 Kelvin = %.2f Celsius\n", test);


    // Task 3: Analysis in original Celsius

    find_hottest(temps, cities, 8, &max_temp, &max_city);

    find_coldest(temps, cities, 8, &min_temp, &min_city);

    printf("\n===== TEMPERATURE ANALYSIS =====\n");

    printf("Hottest city: %s (%.2f C)\n",
           max_city, *max_temp);

    printf("Coldest city: %s (%.2f C)\n",
           min_city, *min_temp);

    printf("Average temperature: %.2f C\n",
           average_temp(temps, 8));


    // Task 2: Choose conversion unit

    printf("\nConvert temperatures to Fahrenheit (F) or Kelvin (K): ");
    scanf(" %c", &choice);

    if (choice == 'F' || choice == 'f')
    {
        convert_array(temps, 8, celsius_to_fahrenheit);
    }
    else if (choice == 'K' || choice == 'k')
    {
        convert_array(temps, 8, celsius_to_kelvin);
    }
    else
    {
        printf("Invalid choice!");
        return 0;
    }


    // Display converted temperatures

    printf("\n===== CITY TEMPERATURES =====\n");

    printf("%-15s %s\n", "City", "Temperature");

    for (i = 0; i < 8; i++)
    {
        printf("%-15s %.2f\n", cities[i], temps[i]);
    }

    return 0;
}
