
#include <stdio.h>
#include <ctype.h>

int count_words(char str[])
{
    int i, count = 0, inWord = 0;

    for (i = 0; str[i] != '\0'; i++)
    {
        if (str[i] != ' ' && str[i] != '\n' && str[i] != '\t')
        {
            if (inWord == 0)
            {
                count++;
                inWord = 1;
            }
        }
        else
        {
            inWord = 0;
        }
    }

    return count;
}

int count_vowels(char str[])
{
    int i, count = 0;
    char ch;

    for (i = 0; str[i] != '\0'; i++)
    {
        ch = tolower(str[i]);

        if (ch == 'a' || ch == 'e' || ch == 'i' ||
            ch == 'o' || ch == 'u')
            count++;
    }

    return count;
}

int count_consonants(char str[])
{
    int i, count = 0;
    char ch;

    for (i = 0; str[i] != '\0'; i++)
    {
        ch = tolower(str[i]);

        if (ch >= 'a' && ch <= 'z')
        {
            if (ch != 'a' && ch != 'e' && ch != 'i' &&
                ch != 'o' && ch != 'u')
                count++;
        }
    }

    return count;
}

int count_digits(char str[])
{
    int i, count = 0;

    for (i = 0; str[i] != '\0'; i++)
    {
        if (str[i] >= '0' && str[i] <= '9')
            count++;
    }

    return count;
}

int count_sentences(char str[])
{
    int i, count = 0;

    for (i = 0; str[i] != '\0'; i++)
    {
        if (str[i] == '.' || str[i] == '!' || str[i] == '?')
            count++;
    }

    return count;
}

int count_spaces(char str[])
{
    int i, count = 0;

    for (i = 0; str[i] != '\0'; i++)
    {
        if (str[i] == ' ')
            count++;
    }

    return count;
}

char most_frequent_char(char str[])
{
    int freq[26] = {0};
    int i, max = 0, index = -1;
    char ch;

    for (i = 0; str[i] != '\0'; i++)
    {
        ch = tolower(str[i]);

        if (ch >= 'a' && ch <= 'z')
        {
            freq[ch - 'a']++;
        }
    }

    for (i = 0; i < 26; i++)
    {
        if (freq[i] > max)
        {
            max = freq[i];
            index = i;
        }
    }

    if (index == -1)
        return '\0';

    return 'a' + index;
}

int main()
{
    char lines[10][500];
    int n, i, total = 0;
    int maxWords = -1, maxLine = 0;

    printf("Enter number of lines (1-10): ");
    scanf("%d", &n);

    if (n < 1 || n > 10)
    {
        printf("Invalid number of lines!");
        return 0;
    }

    getchar();

    for (i = 0; i < n; i++)
    {
        printf("Enter line %d: ", i + 1);
        fgets(lines[i], 500, stdin);
    }

    printf("\n===== TEXT ANALYSIS =====\n");

    for (i = 0; i < n; i++)
    {
        int words = count_words(lines[i]);

        printf("\nLine %d: %s", i + 1, lines[i]);

        printf("Words       : %d\n", words);
        printf("Vowels      : %d\n", count_vowels(lines[i]));
        printf("Consonants  : %d\n", count_consonants(lines[i]));
        printf("Digits      : %d\n", count_digits(lines[i]));
        printf("Sentences   : %d\n", count_sentences(lines[i]));
        printf("Spaces      : %d\n", count_spaces(lines[i]));

        char frequent = most_frequent_char(lines[i]);

        if (frequent != '\0')
            printf("Most Frequent Character: %c\n", frequent);
        else
            printf("Most Frequent Character: None\n");

        total += words;

        if (words > maxWords)
        {
            maxWords = words;
            maxLine = i;
        }
    }

    printf("\n===== FINAL RESULT =====\n");
    printf("Total Words: %d\n", total);
    printf("Line with most words: Line %d\n", maxLine + 1);
    printf("Text: %s", lines[maxLine]);

    return 0;
}

