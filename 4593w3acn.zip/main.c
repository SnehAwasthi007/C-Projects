
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int entry_exists(char date[]) {
    FILE *fp = fopen("diary.txt", "r");
    char line[500];
    char marker[100];

    if (fp == NULL)
        return 0;

    sprintf(marker, "---DATE:%s---", date);

    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, marker)) {
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

void write_entry(char date[], char text[]) {
    FILE *fp = fopen("diary.txt", "a");

    if (fp == NULL) {
        printf("File cannot be opened.\n");
        return;
    }

    fprintf(fp, "---DATE:%s---\n", date);
    fprintf(fp, "%s", text);
    fprintf(fp, "---END---\n");

    fclose(fp);
    printf("Entry saved successfully.\n");
}

void read_entry(char date[]) {
    FILE *fp = fopen("diary.txt", "r");
    char line[500];
    char marker[100];
    int found = 0;

    if (fp == NULL) {
        printf("Diary file does not exist.\n");
        return;
    }

    sprintf(marker, "---DATE:%s---", date);

    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, marker)) {
            found = 1;
            break;
        }
    }

    if (found) {
        while (fgets(line, sizeof(line), fp)) {
            if (strstr(line, "---END---"))
                break;

            printf("%s", line);
        }
    } else {
        printf("No entry found for %s.\n", date);
    }

    fclose(fp);
}

void list_entries() {
    FILE *fp = fopen("diary.txt", "r");
    char line[500];
    int count = 0;

    if (fp == NULL) {
        printf("Diary file does not exist.\n");
        return;
    }

    printf("\nDiary Entries:\n");

    while (fgets(line, sizeof(line), fp)) {
        if (strncmp(line, "---DATE:", 8) == 0) {
            count++;
            line[strcspn(line, "\n")] = '\0';
            printf("%d. %s\n", count, line + 8);
        }
    }

    if (count == 0)
        printf("No entries found.\n");

    fclose(fp);
}

void delete_entry(char date[]) {
    FILE *fp = fopen("diary.txt", "r");
    FILE *temp = fopen("diary_temp.txt", "w");
    char line[500];
    char marker[100];
    int skip = 0, found = 0;

    if (fp == NULL || temp == NULL) {
        printf("File cannot be opened.\n");

        if (fp != NULL)
            fclose(fp);

        if (temp != NULL)
            fclose(temp);

        return;
    }

    sprintf(marker, "---DATE:%s---", date);

    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, marker)) {
            skip = 1;
            found = 1;
            continue;
        }

        if (skip) {
            if (strstr(line, "---END---"))
                skip = 0;

            continue;
        }

        fputs(line, temp);
    }

    fclose(fp);
    fclose(temp);

    if (found) {
        remove("diary.txt");
        rename("diary_temp.txt", "diary.txt");
        printf("Entry deleted successfully.\n");
    } else {
        remove("diary_temp.txt");
        printf("Entry not found.\n");
    }
}

int main() {
    int choice;
    char date[50];
    char text[5000];
    char line[500];
    int len;

    time_t t = time(NULL);
    struct tm *today = localtime(&t);

    char today_date[50];

    strftime(today_date, sizeof(today_date), "%d-%m-%Y", today);

    do {
        printf("\n========== MY DIARY ==========\n");
        printf("1. Write Today's Entry\n");
        printf("2. Read an Entry\n");
        printf("3. List All Entries\n");
        printf("4. Delete an Entry\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");

        scanf("%d", &choice);
        getchar();

        switch (choice) {

            case 1:
                strcpy(date, today_date);

                if (entry_exists(date)) {
                    printf("Entry already exists for today.\n");
                    printf("Delete the old entry first or choose another option.\n");
                    break;
                }

                printf("Write your diary entry (! to finish):\n");

                text[0] = '\0';

                while (fgets(line, sizeof(line), stdin)) {
                    if (strcmp(line, "!\n") == 0 || strcmp(line, "!") == 0)
                        break;

                    len = strlen(text);

                    if (len + strlen(line) < sizeof(text) - 1)
                        strcat(text, line);
                    else {
                        printf("Entry is too long.\n");
                        break;
                    }
                }

                write_entry(date, text);
                break;

            case 2:
                printf("Enter date (DD-MM-YYYY): ");
                scanf("%49s", date);
                read_entry(date);
                break;

            case 3:
                list_entries();
                break;

            case 4:
                printf("Enter date to delete (DD-MM-YYYY): ");
                scanf("%49s", date);
                delete_entry(date);
                break;

            case 5:
                printf("Exiting Diary. Goodbye!\n");
                break;

            default:
                printf("Invalid choice. Try again.\n");
        }

    } while (choice != 5);

    return 0;
}
