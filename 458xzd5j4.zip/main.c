
#include <stdio.h>

// FUNCTION DECLARATIONS

float total_rainfall(float arr[], int n);
float average_rainfall(float arr[], int n);
int wettest_day(float arr[], int n);
int driest_day(float arr[], int n);
int count_above_threshold(float arr[], int n, float threshold);

void enter_data(float arr[], int n);
void display_data(float arr[], int n);
void display_summary(float arr[], int n);


// TASK 1: ENTER RAINFALL DATA

void enter_data(float arr[], int n)
{
    int i;

    for (i = 0; i < n; i++)
    {
        do
        {
            printf("Enter rainfall for Day %d: ", i + 1);
            scanf("%f", &arr[i]);

            if (arr[i] < 0)
            {
                printf("Rainfall cannot be negative. Try again.\n");
            }

        } while (arr[i] < 0);
    }
}


// DISPLAY DATA

void display_data(float arr[], int n)
{
    int i;

    printf("\nDay\tRainfall (mm)\n");
    printf("-------------------------\n");

    for (i = 0; i < n; i++)
    {
        printf("%d\t%.2f\n", i + 1, arr[i]);
    }
}


// TASK 2: TOTAL RAINFALL

float total_rainfall(float arr[], int n)
{
    int i;
    float sum = 0;

    for (i = 0; i < n; i++)
    {
        sum = sum + arr[i];
    }

    return sum;
}


// AVERAGE RAINFALL

float average_rainfall(float arr[], int n)
{
    return total_rainfall(arr, n) / n;
}


// WETTEST DAY

int wettest_day(float arr[], int n)
{
    int i;
    int maxIndex = 0;

    for (i = 1; i < n; i++)
    {
        if (arr[i] > arr[maxIndex])
        {
            maxIndex = i;
        }
    }

    return maxIndex;
}


// DRIEST DAY

int driest_day(float arr[], int n)
{
    int i;
    int minIndex = 0;

    for (i = 1; i < n; i++)
    {
        if (arr[i] < arr[minIndex])
        {
            minIndex = i;
        }
    }

    return minIndex;
}


// COUNT DAYS ABOVE THRESHOLD

int count_above_threshold(float arr[], int n, float threshold)
{
    int i, count = 0;

    for (i = 0; i < n; i++)
    {
        if (arr[i] > threshold)
        {
            count++;
        }
    }

    return count;
}


// DISPLAY SUMMARY

void display_summary(float arr[], int n)
{
    float total, average;
    int wettest, driest, count;

    total = total_rainfall(arr, n);
    average = average_rainfall(arr, n);
    wettest = wettest_day(arr, n);
    driest = driest_day(arr, n);
    count = count_above_threshold(arr, n, 25);

    printf("\n===== Rainfall Summary =====\n");
    printf("Total Rainfall  : %.2f mm\n", total);
    printf("Average per Day : %.2f mm\n", average);

    printf("Wettest Day     : Day %d (%.2f mm)\n",
           wettest + 1, arr[wettest]);

    printf("Driest Day      : Day %d (%.2f mm)\n",
           driest + 1, arr[driest]);

    printf("Days above 25mm : %d\n", count);

    printf("============================\n");
}


// MAIN FUNCTION

int main()
{
    float rainfall1[31], rainfall2[31];
    int days1, days2;
    int choice;
    float total1, total2;
    float avg1, avg2;
    int count1, count2;

    printf("Enter number of days for Month 1 (1-31): ");
    scanf("%d", &days1);

    if (days1 < 1 || days1 > 31)
    {
        printf("Invalid number of days.\n");
        return 0;
    }

    enter_data(rainfall1, days1);

    display_data(rainfall1, days1);
    display_summary(rainfall1, days1);


    printf("\nDo you want to enter second month?\n");
    printf("1. Yes\n2. No\n");
    scanf("%d", &choice);

    if (choice == 1)
    {
        printf("Enter number of days for Month 2 (1-31): ");
        scanf("%d", &days2);

        if (days2 < 1 || days2 > 31)
        {
            printf("Invalid number of days.\n");
            return 0;
        }

        enter_data(rainfall2, days2);

        display_data(rainfall2, days2);
        display_summary(rainfall2, days2);

        total1 = total_rainfall(rainfall1, days1);
        total2 = total_rainfall(rainfall2, days2);

        avg1 = average_rainfall(rainfall1, days1);
        avg2 = average_rainfall(rainfall2, days2);

        count1 = count_above_threshold(rainfall1, days1, 25);
        count2 = count_above_threshold(rainfall2, days2, 25);

        printf("\n===== MONTH COMPARISON =====\n");

        if (total1 > total2)
            printf("Higher rainfall: Month 1\n");
        else if (total2 > total1)
            printf("Higher rainfall: Month 2\n");
        else
            printf("Both months have equal rainfall.\n");

        printf("Month 1 days above 25mm: %d\n", count1);
        printf("Month 2 days above 25mm: %d\n", count2);

        printf("Average difference: %.2f mm\n",
               (avg1 > avg2) ? avg1 - avg2 : avg2 - avg1);

        printf("============================\n");
    }

    return 0;
}
